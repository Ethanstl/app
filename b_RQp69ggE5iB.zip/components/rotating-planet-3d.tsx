"use client"

import { Canvas, useFrame } from "@react-three/fiber"
import { useRef, useMemo } from "react"
import * as THREE from "three"

function Planet() {
  const meshRef = useRef<THREE.Mesh>(null)
  const wireframeRef = useRef<THREE.LineSegments>(null)

  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.15
      meshRef.current.rotation.x = 0.2
    }
    if (wireframeRef.current) {
      wireframeRef.current.rotation.y += delta * 0.15
      wireframeRef.current.rotation.x = 0.2
    }
  })

  const gridGeometry = useMemo(() => {
    const geometry = new THREE.SphereGeometry(2, 32, 24)
    const wireframe = new THREE.WireframeGeometry(geometry)
    return wireframe
  }, [])

  return (
    <group position={[2.5, 0, 0]}>
      {/* Main sphere with gradient-like material */}
      <mesh ref={meshRef}>
        <sphereGeometry args={[2, 64, 48]} />
        <meshStandardMaterial
          color="#1a3366"
          transparent
          opacity={0.6}
          roughness={0.8}
          metalness={0.1}
        />
      </mesh>

      {/* Wireframe grid overlay */}
      <lineSegments ref={wireframeRef} geometry={gridGeometry}>
        <lineBasicMaterial
          color="#2a4a80"
          transparent
          opacity={0.5}
          linewidth={1}
        />
      </lineSegments>

      {/* Outer glow ring */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <ringGeometry args={[2.1, 2.5, 64]} />
        <meshBasicMaterial
          color="#1a3366"
          transparent
          opacity={0.15}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Atmospheric glow */}
      <mesh>
        <sphereGeometry args={[2.2, 32, 32]} />
        <meshBasicMaterial
          color="#2a4a80"
          transparent
          opacity={0.1}
          side={THREE.BackSide}
        />
      </mesh>
    </group>
  )
}

function FloatingParticles() {
  const particlesRef = useRef<THREE.Points>(null)

  const particlesGeometry = useMemo(() => {
    const geometry = new THREE.BufferGeometry()
    const count = 100
    const positions = new Float32Array(count * 3)

    for (let i = 0; i < count * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 15
      positions[i + 1] = (Math.random() - 0.5) * 10
      positions[i + 2] = (Math.random() - 0.5) * 8
    }

    geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3))
    return geometry
  }, [])

  useFrame((_, delta) => {
    if (particlesRef.current) {
      particlesRef.current.rotation.y += delta * 0.02
    }
  })

  return (
    <points ref={particlesRef} geometry={particlesGeometry}>
      <pointsMaterial
        color="#3a5a90"
        size={0.03}
        transparent
        opacity={0.6}
        sizeAttenuation
      />
    </points>
  )
}

export function RotatingPlanet3D() {
  return (
    <div className="absolute inset-0 -z-10 opacity-90">
      <Canvas
        camera={{ position: [0, 0, 6], fov: 50 }}
        gl={{ alpha: true, antialias: true }}
        style={{ background: "transparent" }}
      >
        <ambientLight intensity={0.4} />
        <directionalLight position={[5, 5, 5]} intensity={0.8} color="#ffffff" />
        <directionalLight position={[-5, -5, -5]} intensity={0.3} color="#4a6a9a" />
        
        <Planet />
        <FloatingParticles />
      </Canvas>
    </div>
  )
}
