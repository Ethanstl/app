"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CtaSection() {
  return (
    <section className="py-32 px-6">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="max-w-3xl mx-auto text-center"
      >
        <h2 className="text-3xl md:text-5xl font-light tracking-tight text-foreground text-balance">
          Prêt à faire fructifier{" "}
          <span className="font-medium">votre avenir ?</span>
        </h2>
        <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto">
          Rejoignez plus de 2 millions d&apos;utilisateurs qui ont choisi Éleva 
          pour gérer leur patrimoine.
        </p>
        <div className="mt-10">
          <Button size="lg" className="h-14 px-8 text-base rounded-full">
            Créer mon compte gratuit
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
        <p className="mt-6 text-sm text-muted-foreground">
          Inscription en 2 minutes. Aucune carte bancaire requise.
        </p>
      </motion.div>
    </section>
  )
}
