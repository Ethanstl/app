"use client"

import { motion } from "framer-motion"

const stats = [
  { value: "2.5M+", label: "Utilisateurs actifs" },
  { value: "8.2%", label: "Rendement moyen annuel" },
  { value: "0€", label: "Frais de gestion" },
  { value: "24/7", label: "Support disponible" },
]

export function StatsSection() {
  return (
    <section className="py-24 px-6 bg-primary text-primary-foreground">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-12">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center"
            >
              <p className="text-4xl md:text-5xl font-light tracking-tight">
                {stat.value}
              </p>
              <p className="mt-2 text-sm opacity-70">
                {stat.label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
