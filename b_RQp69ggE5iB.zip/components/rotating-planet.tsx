"use client"

import { useEffect, useRef } from "react"

export function RotatingPlanet() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationId: number
    let rotation = 0

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resize()
    window.addEventListener("resize", resize)

    // Planet settings
    const planet = {
      x: () => canvas.width * 0.75,
      y: () => canvas.height * 0.5,
      radius: () => Math.min(canvas.width, canvas.height) * 0.4,
    }

    // Grid lines for the planet surface
    const drawPlanet = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      
      const centerX = planet.x()
      const centerY = planet.y()
      const radius = planet.radius()

      // Planet base with gradient
      const gradient = ctx.createRadialGradient(
        centerX - radius * 0.3,
        centerY - radius * 0.3,
        0,
        centerX,
        centerY,
        radius
      )
      gradient.addColorStop(0, "rgba(30, 60, 120, 0.7)")
      gradient.addColorStop(0.5, "rgba(20, 45, 100, 0.55)")
      gradient.addColorStop(1, "rgba(10, 30, 80, 0.4)")

      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.fillStyle = gradient
      ctx.fill()

      // Planet outline
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.strokeStyle = "rgba(25, 50, 100, 0.8)"
      ctx.lineWidth = 2
      ctx.stroke()

      // Latitude lines
      ctx.save()
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.clip()

      const latitudeCount = 8
      for (let i = 1; i < latitudeCount; i++) {
        const y = centerY - radius + (radius * 2 * i) / latitudeCount
        const latRadius = Math.sqrt(radius * radius - Math.pow(y - centerY, 2))
        
        ctx.beginPath()
        ctx.ellipse(centerX, y, latRadius, latRadius * 0.1, 0, 0, Math.PI * 2)
        ctx.strokeStyle = "rgba(40, 70, 130, 0.7)"
        ctx.lineWidth = 1.5
        ctx.stroke()
      }

      // Longitude lines (rotating)
      const longitudeCount = 12
      for (let i = 0; i < longitudeCount; i++) {
        const angle = (i / longitudeCount) * Math.PI + rotation
        
        ctx.save()
        ctx.translate(centerX, centerY)
        ctx.rotate(angle)
        
        // Draw ellipse for longitude
        ctx.beginPath()
        ctx.ellipse(0, 0, radius * 0.15, radius, 0, 0, Math.PI * 2)
        ctx.strokeStyle = "rgba(40, 70, 130, 0.6)"
        ctx.lineWidth = 1.5
        ctx.stroke()
        ctx.restore()
      }

      ctx.restore()

      // Atmospheric glow
      const glowGradient = ctx.createRadialGradient(
        centerX,
        centerY,
        radius * 0.85,
        centerX,
        centerY,
        radius * 1.4
      )
      glowGradient.addColorStop(0, "rgba(30, 60, 120, 0.35)")
      glowGradient.addColorStop(1, "rgba(20, 45, 100, 0)")

      ctx.beginPath()
      ctx.arc(centerX, centerY, radius * 1.4, 0, Math.PI * 2)
      ctx.fillStyle = glowGradient
      ctx.fill()
    }

    const animate = () => {
      rotation += 0.002
      drawPlanet()
      animationId = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resize)
      cancelAnimationFrame(animationId)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none"
      style={{ opacity: 0.85 }}
    />
  )
}
