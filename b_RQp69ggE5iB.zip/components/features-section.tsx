"use client"

import { motion } from "framer-motion"
import { TrendingUp, Shield, Sparkles } from "lucide-react"

const features = [
  {
    icon: TrendingUp,
    title: "Investissement automatisé",
    description: "Configurez vos objectifs et laissez notre algorithme optimiser vos placements en fonction de votre profil de risque.",
  },
  {
    icon: Shield,
    title: "Sécurité maximale",
    description: "Vos fonds sont protégés jusqu&apos;à 100 000€. Authentification renforcée et chiffrement de bout en bout.",
  },
  {
    icon: Sparkles,
    title: "Zéro frais cachés",
    description: "Une tarification transparente et simple. Pas de commissions sur vos investissements, jamais de surprises.",
  },
]

export function FeaturesSection() {
  return (
    <section className="py-32 px-6">
      <div className="max-w-6xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-3xl md:text-5xl font-light tracking-tight text-foreground text-balance">
            Conçu pour <span className="font-medium">votre réussite</span>
          </h2>
          <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto">
            Des outils puissants, une expérience simple
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-3 gap-12 md:gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="group"
            >
              <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-medium text-foreground mb-3">
                {feature.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
