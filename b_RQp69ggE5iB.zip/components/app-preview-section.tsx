"use client"

import { motion } from "framer-motion"

export function AppPreviewSection() {
  return (
    <section className="py-32 px-6 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-light tracking-tight text-foreground text-balance">
            Tout votre patrimoine,{" "}
            <span className="font-medium">en un coup d&apos;œil</span>
          </h2>
          <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto">
            Suivez vos investissements et votre épargne depuis une interface claire et intuitive
          </p>
        </motion.div>
        
        {/* Phone Mockup */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex justify-center"
        >
          <div className="relative">
            {/* Phone Frame */}
            <div className="w-[280px] md:w-[320px] bg-foreground rounded-[3rem] p-3 shadow-2xl">
              <div className="bg-card rounded-[2.5rem] overflow-hidden">
                {/* Status Bar */}
                <div className="px-6 pt-4 pb-2 flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">9:41</span>
                  <div className="flex gap-1">
                    <div className="w-4 h-2 bg-foreground/20 rounded-sm" />
                    <div className="w-4 h-2 bg-foreground/20 rounded-sm" />
                    <div className="w-6 h-3 bg-foreground rounded-sm" />
                  </div>
                </div>
                
                {/* App Content */}
                <div className="px-6 pb-8">
                  <p className="text-sm text-muted-foreground mt-4">Valeur totale</p>
                  <p className="text-4xl font-light tracking-tight mt-1">47 842,50 €</p>
                  <p className="text-sm text-accent mt-1">+2.34% ce mois</p>
                  
                  {/* Mini Chart */}
                  <div className="mt-6 h-24 flex items-end gap-1">
                    {[40, 55, 45, 65, 50, 70, 60, 75, 68, 80, 72, 85].map((height, i) => (
                      <div 
                        key={i}
                        className="flex-1 bg-accent/20 rounded-t-sm"
                        style={{ height: `${height}%` }}
                      />
                    ))}
                  </div>
                  
                  {/* Portfolio Items */}
                  <div className="mt-8 space-y-4">
                    <div className="flex justify-between items-center py-3 border-b border-border">
                      <div>
                        <p className="font-medium text-sm">Livret A</p>
                        <p className="text-xs text-muted-foreground">Épargne sécurisée</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-sm">12 500 €</p>
                        <p className="text-xs text-muted-foreground">+3.0%</p>
                      </div>
                    </div>
                    <div className="flex justify-between items-center py-3 border-b border-border">
                      <div>
                        <p className="font-medium text-sm">ETF Monde</p>
                        <p className="text-xs text-muted-foreground">Investissement</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-sm">28 342 €</p>
                        <p className="text-xs text-accent">+12.4%</p>
                      </div>
                    </div>
                    <div className="flex justify-between items-center py-3">
                      <div>
                        <p className="font-medium text-sm">Crypto</p>
                        <p className="text-xs text-muted-foreground">Diversification</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-sm">7 000 €</p>
                        <p className="text-xs text-accent">+5.2%</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-accent/5 rounded-full blur-3xl" />
          </div>
        </motion.div>
      </div>
    </section>
  )
}
